export const environment = {
  api: 'http://localhost:3000',
};
